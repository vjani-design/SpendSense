package com.example.spendsense.model

data class Transaction(
    val id: String = "",
    val userId: String = "",   // ✅ ADD THIS
    val type: String = "",
    val category: String = "",
    val amount: Double = 0.0,
    val note: String = "",
    val paymentMethod: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    var isRecurring: Boolean = false,
    var recurrenceType: String? = null, // "DAILY", "WEEKLY", "MONTHLY"
    var nextDueDate: Long? = null
)