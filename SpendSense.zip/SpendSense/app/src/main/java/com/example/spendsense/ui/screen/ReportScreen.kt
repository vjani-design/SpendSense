package com.example.spendsense.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.spendsense.viewmodel.TransactionViewModel
import com.example.spendsense.ui.theme.*
import com.example.spendsense.ui.theme.neonBackground
import com.example.spendsense.ui.theme.glass

@Composable
fun ReportsScreen(
    navController: NavController,
    transactionViewModel: TransactionViewModel
) {

    val transactions by transactionViewModel.transactions.collectAsState()
    val income by transactionViewModel.income.collectAsState()
    val expense by transactionViewModel.expense.collectAsState()
    val balance by transactionViewModel.balance.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .neonBackground()
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🔷 Title
            Text(
                text = "Reports",
                style = MaterialTheme.typography.headlineMedium,
                color = White
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 🔷 Summary Cards (same style as Home)
            Box(
                Modifier
                    .fillMaxWidth()
                    .glass()
                    .padding(16.dp)
            ) {
                Column {
                    Text("Total Transactions: ${transactions.size}", color = White)
                    Text("Income: ₹$income", color = Green)
                    Text("Expense: ₹$expense", color = Red)
                    Text("Balance: ₹$balance", color = White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 🔷 Export Button
            Button(
                onClick = {
                    // TODO CSV
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export CSV (Coming Soon)")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 🔷 Back Button
            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Back")
            }
        }
    }
}