package com.example.spendsense.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.spendsense.ui.theme.*
import com.example.spendsense.viewmodel.TransactionViewModel
import com.example.spendsense.ui.components.IncomeExpensePieChart
import com.example.spendsense.ui.components.MonthlyBarChart

@Composable
fun AnalyticsScreen(
    navController: NavController,
    viewModel: TransactionViewModel = viewModel()
) {

    val transactions by viewModel.transactions.collectAsState()

    val expenseList = remember(transactions) {
        transactions.filter { it.type == "EXPENSE" }
    }

    val incomeList = remember(transactions) {
        transactions.filter { it.type == "INCOME" }
    }

    val totalExpense = remember(expenseList) {
        expenseList.sumOf { it.amount }
    }

    val totalIncome = remember(incomeList) {
        incomeList.sumOf { it.amount }
    }

    val balance = totalIncome - totalExpense

    val categoryMap = remember(expenseList) {
        expenseList
            .groupBy { it.category }
            .mapValues { it.value.sumOf { t -> t.amount } }
    }

    val mostSpent = remember(categoryMap) {
        categoryMap.maxByOrNull { it.value }?.key ?: "None"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .neonBackground()
            .padding(16.dp)
    ) {

        Text(
            text = "📊 Analytics",
            color = White,
            style = MaterialTheme.typography.headlineLarge
        )

        Spacer(modifier = Modifier.height(24.dp))

        // ---------------- SUMMARY ----------------
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = PurpleMain.copy(alpha = 0.2f)
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {

                Text("💰 Income: $totalIncome", color = White)
                Text("💸 Expense: $totalExpense", color = White)
                Text("📊 Balance: $balance", color = White)
                Text("🔥 Top Category: $mostSpent", color = White)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ---------------- PIE CHART ----------------
        Text(
            text = "Income vs Expense",
            color = White,
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(10.dp))

        IncomeExpensePieChart(
            income = totalIncome.toFloat(),
            expense = totalExpense.toFloat()
        )

        Spacer(modifier = Modifier.height(24.dp))

        // ---------------- CATEGORY ----------------
        Text(
            text = "Category-wise Spending",
            color = White,
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .glass(),
            contentAlignment = Alignment.Center
        ) {

            if (categoryMap.isEmpty()) {
                Text("No data available", color = White.copy(0.7f))
            } else {
                Column {

                    categoryMap.forEach { entry ->
                        Text(
                            text = "${entry.key} : ${entry.value}",
                            color = White.copy(0.8f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ---------------- MONTHLY BAR CHART ----------------
        Text(
            text = "Monthly Trend",
            color = White,
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(10.dp))

        MonthlyBarChart(transactions)

        Spacer(modifier = Modifier.height(24.dp))

        // ---------------- BACK ----------------
        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PurpleMain)
        ) {
            Text("Back", color = White)
        }
    }
}