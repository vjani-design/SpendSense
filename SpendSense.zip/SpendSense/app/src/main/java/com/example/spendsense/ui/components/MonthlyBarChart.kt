package com.example.spendsense.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.spendsense.model.Transaction
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import java.util.*

@Composable
fun MonthlyBarChart(transactions: List<Transaction>) {

    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
        factory = { context ->

            val chart = BarChart(context)

            val grouped = transactions.groupBy { t ->
                val cal = Calendar.getInstance()
                cal.timeInMillis = t.timestamp
                "${cal.get(Calendar.MONTH) + 1}"
            }

            val entries = grouped.map { (month, list) ->
                val expense = list.filter { it.type == "EXPENSE" }
                    .sumOf { it.amount }

                BarEntry(month.toFloat(), expense.toFloat())
            }

            val dataSet = BarDataSet(entries, "Monthly Expense")

            chart.data = BarData(dataSet)
            chart.invalidate()

            chart
        }
    )
}