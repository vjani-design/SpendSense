package com.example.spendsense.ui.screen

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.spendsense.ui.theme.*
import com.example.spendsense.viewmodel.TransactionViewModel
import com.example.spendsense.ui.components.*
import com.example.spendsense.utils.NotificationHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun HomeScreen(
    navController: NavController,
    transactionViewModel: TransactionViewModel = viewModel()
) {

    val transactions by transactionViewModel.transactions.collectAsState()
    val income by transactionViewModel.income.collectAsState()
    val expense by transactionViewModel.expense.collectAsState()
    val balance by transactionViewModel.balance.collectAsState()

    val sortedList = remember(transactions) {
        transactions.sortedByDescending { it.timestamp }
    }
    val budgetAlertEvent by transactionViewModel.budgetAlertEvent.collectAsState()

    val context = LocalContext.current
    val activity = context as Activity

    val budgetAlert by transactionViewModel.budgetAlert.collectAsState()
    val percent by transactionViewModel.budgetUsedPercent.collectAsState()
    val user = FirebaseAuth.getInstance().currentUser
    LaunchedEffect(user?.uid) {
        if (user != null) {
            transactionViewModel.loadTransactions()
        } else {
            transactionViewModel.clearData()
        }
    }
    var showAnalytics by remember { mutableStateOf(false) }
    var userName by remember { mutableStateOf("U") }


    LaunchedEffect(budgetAlertEvent) {
        if (budgetAlertEvent) {

            NotificationHelper.showBudgetAlert(
                context,
                "⚠ Budget limit reached!"
            )

            transactionViewModel.resetBudgetAlertEvent()
        }
    }
    // ✅ NOTIFICATION PERMISSION (Android 13+)
    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    activity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    activity,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1
                )
            }
        }
    }


    // FETCH USER NAME
    LaunchedEffect(Unit) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid

        if (uid != null) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener {
                    userName = it.getString("name") ?: "User"
                }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .neonBackground()
    ) {

        Column(modifier = Modifier.fillMaxSize()) {

            // TOP BAR
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepSpacePurple)
                    .height(64.dp)
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        text = "SpendSense",
                        color = White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White.copy(alpha = 0.1f))
                            .clickable { navController.navigate("profile") },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userName.firstOrNull()?.uppercase() ?: "U",
                            color = White,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // BALANCE
            Column(Modifier.padding(16.dp)) {

                Box(
                    Modifier
                        .fillMaxWidth()
                        .glass()
                        .padding(16.dp)
                ) {
                    Text(
                        "Balance: ₹$balance",
                        color = White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(Modifier.height(12.dp))

                Row {
                    Box(
                        Modifier.weight(1f).glass().padding(12.dp)
                    ) {
                        Text("Income: ₹$income", color = Green)
                    }

                    Spacer(Modifier.width(10.dp))

                    Box(
                        Modifier.weight(1f).glass().padding(12.dp)
                    ) {
                        Text("Expense: ₹$expense", color = Red)
                    }
                }
            }

            // STATUS
            Text(
                text = when {
                    expense > income -> "⚠ Overspending!"
                    expense > income * 0.8 -> "⚠ High spending"
                    else -> "✅ Healthy finances"
                },
                color = White,
                modifier = Modifier.padding(16.dp)
            )

            val mostSpent = transactionViewModel.getMostSpentCategory(transactions)

            Text(
                text = "Top Category: $mostSpent",
                color = White,
                modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
            )

            // BUDGET
            val budget by transactionViewModel.budget.collectAsState()
            val budgetPercent by transactionViewModel.budgetUsedPercent.collectAsState()

            Column(Modifier.padding(horizontal = 16.dp)) {

                Text("Budget: ₹$budget", color = White)

                LinearProgressIndicator(
                    progress = if (budget > 0)
                        (budgetPercent.coerceIn(0.0, 100.0) / 100).toFloat()
                    else 0f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                )

                Text(
                    "Used: ${"%.1f".format(budgetPercent)}%",
                    color = if (budgetAlert) Red else White
                )

                if (budgetAlert) {
                    Text("⚠ Budget almost full!", color = Red)
                }
            }

            // ANALYTICS
            Button(
                onClick = { showAnalytics = !showAnalytics },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(if (showAnalytics) "Hide Analytics" else "Show Analytics")
            }

            if (showAnalytics) {
                IncomeExpensePieChart(
                    income = income.toFloat(),
                    expense = expense.toFloat()
                )
            }

            // TRANSACTIONS
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp)
            ) {
                items(sortedList, key = { it.id }) { item ->

                    SwipeToDeleteItem(
                        onDelete = {
                            transactionViewModel.delete(item.id)
                        }
                    ) {
                        TransactionItem(
                            transaction = item,
                            onDelete = {
                                transactionViewModel.delete(item.id)
                            },
                            onEdit = {
                                navController.navigate("editTransaction/${item.id}")                            }
                        )
                    }
                }
            }
        }

        FabMenu(navController)
    }
}