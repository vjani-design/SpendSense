package com.example.spendsense.utils

import com.example.spendsense.model.Transaction

object CsvExporter {

    fun export(list: List<Transaction>): String {

        val header = "ID,TYPE,CATEGORY,AMOUNT,NOTE,PAYMENT,TIMESTAMP\n"

        val rows = list.joinToString("\n") {
            "${it.id},${it.type},${it.category},${it.amount},${it.note},${it.paymentMethod},${it.timestamp}"
        }

        return header + rows
    }
}