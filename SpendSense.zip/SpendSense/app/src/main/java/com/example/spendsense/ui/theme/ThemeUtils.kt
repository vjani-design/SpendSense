package com.example.spendsense.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// 🌌 BACKGROUND GRADIENT
fun Modifier.neonBackground(): Modifier {
    return this.background(
        brush = Brush.verticalGradient(
            colors = listOf(
                DeepSpacePurple,
                IndigoBase,
                DarkVoid
            )
        )
    )
}

// 💎 GLASSMORPHISM EFFECT
fun Modifier.glass(): Modifier {
    return this
        .clip(RoundedCornerShape(20.dp))
        .background(Color.White.copy(alpha = 0.08f))
        .border(
            width = 1.dp,
            color = Color.White.copy(alpha = 0.15f),
            shape = RoundedCornerShape(20.dp)
        )
}
@Composable
fun customTextFieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent,
    unfocusedContainerColor = Color.Transparent,
    focusedTextColor = White,
    unfocusedTextColor = White,
    cursorColor = NeonPurple,
    focusedIndicatorColor = NeonPink,
    unfocusedIndicatorColor = White.copy(alpha = 0.3f)
)