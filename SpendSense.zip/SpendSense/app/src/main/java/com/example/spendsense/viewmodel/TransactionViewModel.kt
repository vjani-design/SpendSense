package com.example.spendsense.viewmodel

import androidx.lifecycle.ViewModel
import com.example.spendsense.data.repository.FirestoreRepository
import com.example.spendsense.model.Transaction
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Calendar
import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileWriter

enum class BudgetType {
    WEEKLY,
    MONTHLY
}

class TransactionViewModel : ViewModel() {

    private val repo = FirestoreRepository()

    // ================= STATES =================
    private val _transactions = MutableStateFlow<List<Transaction>>(emptyList())
    val transactions: StateFlow<List<Transaction>> = _transactions

    private val _income = MutableStateFlow(0.0)
    val income: StateFlow<Double> = _income

    private val _expense = MutableStateFlow(0.0)
    val expense: StateFlow<Double> = _expense

    private val _balance = MutableStateFlow(0.0)
    val balance: StateFlow<Double> = _balance

    private val _budget = MutableStateFlow(0.0)
    val budget: StateFlow<Double> = _budget

    private val _budgetType = MutableStateFlow(BudgetType.MONTHLY)
    val budgetType: StateFlow<BudgetType> = _budgetType

    private val _budgetUsedPercent = MutableStateFlow(0.0)
    val budgetUsedPercent: StateFlow<Double> = _budgetUsedPercent

    private val _budgetAlert = MutableStateFlow(false)
    val budgetAlert: StateFlow<Boolean> = _budgetAlert

    private val _budgetAlertEvent = MutableStateFlow(false)
    val budgetAlertEvent: StateFlow<Boolean> = _budgetAlertEvent

    private val _navigateHomeEvent = MutableStateFlow(false)
    val navigateHomeEvent: StateFlow<Boolean> = _navigateHomeEvent

    private var lastAlertShownAt = 0L

    // ================= FIXED: REMOVE AUTO INIT BUG =================
    init {
        clearData()
    }

    // ================= MANUAL LOAD AFTER LOGIN =================

    fun loadAllData() {
        loadTransactions()
        loadBudget()
    }

    fun loadBudget() {
        repo.getBudget { value, type ->
            _budget.value = value
            _budgetType.value = BudgetType.valueOf(type)
            calculateBudget(_expense.value)
        }
    }

    fun clearData() {
        _transactions.value = emptyList()
        _income.value = 0.0
        _expense.value = 0.0
        _balance.value = 0.0
        _budget.value = 0.0
        _budgetUsedPercent.value = 0.0
        _budgetAlert.value = false
        _budgetAlertEvent.value = false
        _navigateHomeEvent.value = false
    }

    // ================= LOAD =================
    fun loadTransactions() {

        val uid = FirebaseAuth.getInstance().currentUser?.uid

        if (uid.isNullOrEmpty()) {
            clearData()
            return
        }

        repo.getTransactions { list ->

            val incomeList = list.filter { it.type == "INCOME" }
            val expenseList = list.filter { it.type == "EXPENSE" }

            val totalIncome = incomeList.sumOf { it.amount }
            val totalExpense = expenseList.sumOf { it.amount }

            _transactions.value = list
            _income.value = totalIncome
            _expense.value = totalExpense
            _balance.value = totalIncome - totalExpense

            calculateBudget(totalExpense)
        }
    }

    // ================= ADD =================
    fun add(transaction: Transaction) {
        repo.addTransaction(transaction) { success ->
            if (success) {
                loadAllData()
                _navigateHomeEvent.value = true

                if (transaction.type == "EXPENSE") {
                    triggerBudgetCheck()
                }
            }
        }
    }

    // ================= UPDATE =================
    fun update(transaction: Transaction) {
        if (transaction.id.isEmpty()) return

        repo.updateTransaction(transaction) { success ->
            if (success) {
                loadAllData()

                if (transaction.type == "EXPENSE") {
                    triggerBudgetCheck()
                }
            }
        }
    }

    // ================= DELETE =================
    fun delete(id: String) {
        repo.deleteTransaction(id) {
            loadAllData()
        }
    }

    // ================= BUDGET =================
    fun setBudget(value: Double, type: BudgetType = BudgetType.MONTHLY) {
        _budget.value = value
        _budgetType.value = type

        repo.saveBudget(value, type.name)
        calculateBudget(_expense.value)
    }

    private fun calculateBudget(totalExpense: Double) {

        val budgetValue = _budget.value

        if (budgetValue <= 0.0) {
            _budgetUsedPercent.value = 0.0
            _budgetAlert.value = false
            return
        }

        val adjusted = when (_budgetType.value) {
            BudgetType.WEEKLY -> budgetValue / 4.0
            BudgetType.MONTHLY -> budgetValue
        }

        val percent = (totalExpense / adjusted) * 100

        _budgetUsedPercent.value = percent.coerceAtLeast(0.0)
        _budgetAlert.value = percent >= 80
    }

    fun triggerBudgetCheck() {

        calculateBudget(_expense.value)

        val now = System.currentTimeMillis()

        if (_budgetAlert.value && now - lastAlertShownAt > 30000) {
            _budgetAlertEvent.value = true
            lastAlertShownAt = now
        }
    }
    fun getMostSpentCategory(transactions: List<Transaction>): String {

        val categoryTotals = transactions
            .filter { it.type == "EXPENSE" }
            .groupBy { it.category }
            .mapValues { entry ->
                entry.value.sumOf { it.amount }
            }

        return categoryTotals.maxByOrNull { it.value }?.key ?: "None"
    }
    fun resetBudgetAlertEvent() {
        _budgetAlertEvent.value = false
    }
    fun getTransactionsByDateRange(
        startTime: Long,
        endTime: Long
    ): List<Transaction> {

        return _transactions.value.filter {
            it.timestamp in startTime..endTime
        }
    }
    fun getReportSummary(
        startTime: Long,
        endTime: Long
    ): Map<String, Double> {

        val filtered = getTransactionsByDateRange(startTime, endTime)

        val income = filtered
            .filter { it.type == "INCOME" }
            .sumOf { it.amount }

        val expense = filtered
            .filter { it.type == "EXPENSE" }
            .sumOf { it.amount }

        return mapOf(
            "income" to income,
            "expense" to expense,
            "balance" to (income - expense)
        )
    }
    fun exportTransactionsToCSV(context: Context): File? {

        return try {

            val fileName = "spendsense_report_${System.currentTimeMillis()}.csv"

            val file = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                fileName
            )

            val writer = FileWriter(file)

            // HEADER
            writer.append("ID,Type,Amount,Category,Note,Timestamp\n")

            // DATA
            _transactions.value.forEach { t ->
                writer.append("${t.id},")
                writer.append("${t.type},")
                writer.append("${t.amount},")
                writer.append("${t.category},")
                writer.append("${t.note},")
                writer.append("${t.timestamp}\n")
            }

            writer.flush()
            writer.close()

            file

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    fun shareCSVFile(context: Context, file: File) {

        val uri = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(
            Intent.createChooser(intent, "Share Report")
        )
    }
    fun getMonthlyTrend(): Map<String, Pair<Double, Double>> {

        val grouped = _transactions.value.groupBy { transaction ->

            val calendar = Calendar.getInstance()
            calendar.timeInMillis = transaction.timestamp

            val month = calendar.get(Calendar.MONTH) + 1
            val year = calendar.get(Calendar.YEAR)

            "$month/$year"
        }

        return grouped.mapValues { entry ->

            val income = entry.value
                .filter { it.type == "INCOME" }
                .sumOf { it.amount }

            val expense = entry.value
                .filter { it.type == "EXPENSE" }
                .sumOf { it.amount }

            Pair(income, expense)
        }.toSortedMap()
    }
}