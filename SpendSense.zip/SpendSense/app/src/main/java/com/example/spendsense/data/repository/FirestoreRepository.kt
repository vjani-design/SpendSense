package com.example.spendsense.data.repository

import com.example.spendsense.model.Transaction
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class FirestoreRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private fun userId(): String {
        return auth.currentUser?.uid ?: ""
    }

    // ================= TRANSACTIONS =================

    fun addTransaction(transaction: Transaction, onResult: (Boolean) -> Unit) {

        val uid = userId()

        val docRef = db.collection("users")
            .document(uid)
            .collection("transactions")
            .document()

        val data = transaction.copy(
            id = docRef.id,
            userId = uid
        )

        docRef.set(data)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    fun getTransactions(onResult: (List<Transaction>) -> Unit) {

        val uid = userId()

        db.collection("users")
            .document(uid)
            .collection("transactions")
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    onResult(snap.toObjects(Transaction::class.java))
                } else {
                    onResult(emptyList())
                }
            }
    }

    fun deleteTransaction(id: String, onResult: (Boolean) -> Unit) {

        val uid = userId()

        db.collection("users")
            .document(uid)
            .collection("transactions")
            .document(id)
            .delete()
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    fun updateTransaction(transaction: Transaction, onResult: (Boolean) -> Unit) {

        val uid = userId()

        db.collection("users")
            .document(uid)
            .collection("transactions")
            .document(transaction.id)
            .set(transaction.copy(userId = uid))
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    // ================= BUDGET (FIXED) =================

    fun saveBudget(budget: Double, type: String) {

        val uid = userId()

        val data = mapOf(
            "budget" to budget,
            "type" to type
        )

        db.collection("users")
            .document(uid)
            .collection("budget")
            .document("main")
            .set(data)   // 🔥 FIXED (you were missing this)
    }

    fun getBudget(onResult: (Double, String) -> Unit) {

        val uid = userId()

        db.collection("users")
            .document(uid)
            .collection("budget")
            .document("main")
            .get()
            .addOnSuccessListener {

                val budget = it.getDouble("budget") ?: 0.0
                val type = it.getString("type") ?: "MONTHLY"

                onResult(budget, type)
            }
            .addOnFailureListener {
                onResult(0.0, "MONTHLY")
            }
    }
}